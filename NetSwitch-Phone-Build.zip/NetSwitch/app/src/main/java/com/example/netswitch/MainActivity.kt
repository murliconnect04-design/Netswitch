
package com.example.netswitch

import android.app.Activity
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.net.VpnService
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {

    companion object {
        const val PREFS_NAME = "netswitch_settings"
        const val KEY_BLOCKED_APPS = "blocked_apps"
    }

    private var pendingBlocked = mutableStateOf<Set<String>>(emptySet())
    private var vpnApproved = false

    private val vpnPermissionLauncher =
        registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                vpnApproved = true
                applyBlockedApps(pendingBlocked.value)
            }
        }

    private fun loadBlockedApps(): Set<String> {
        return getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .getStringSet(KEY_BLOCKED_APPS, emptySet())
            ?.toSet() ?: emptySet()
    }

    private fun saveBlockedApps(blocked: Set<String>) {
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .edit()
            .putStringSet(KEY_BLOCKED_APPS, blocked.toSet())
            .apply()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val savedBlocked = loadBlockedApps()
        pendingBlocked.value = savedBlocked

        setContent {
            MaterialTheme {
                NetSwitchScreen(
                    initialBlocked = savedBlocked,
                    onBlockedAppsChanged = { blocked ->
                        pendingBlocked.value = blocked
                        saveBlockedApps(blocked)

                        if (blocked.isEmpty()) {
                            stopService(
                                Intent(this, FirewallVpnService::class.java)
                            )
                            vpnApproved = false
                        } else {
                            val prepareIntent = VpnService.prepare(this)
                            if (prepareIntent == null) {
                                vpnApproved = true
                                applyBlockedApps(blocked)
                            } else {
                                vpnPermissionLauncher.launch(prepareIntent)
                            }
                        }
                    },
                    loadApps = { loadLaunchableApps() }
                )
            }
        }

        // Restore the saved firewall when the app is opened again.
        if (savedBlocked.isNotEmpty()) {
            val prepareIntent = VpnService.prepare(this)
            if (prepareIntent == null) {
                vpnApproved = true
                applyBlockedApps(savedBlocked)
            } else {
                vpnPermissionLauncher.launch(prepareIntent)
            }
        }
    }

    private fun applyBlockedApps(blocked: Set<String>) {
        if (blocked.isEmpty()) {
            stopService(Intent(this, FirewallVpnService::class.java))
            return
        }

        if (!vpnApproved) return

        val intent = Intent(this, FirewallVpnService::class.java).apply {
            action = FirewallVpnService.ACTION_UPDATE
            putStringArrayListExtra(
                FirewallVpnService.EXTRA_BLOCKED_PACKAGES,
                ArrayList(blocked)
            )
        }

        androidx.core.content.ContextCompat.startForegroundService(this, intent)
    }

    private suspend fun loadLaunchableApps(): List<AppInfo> =
        withContext(Dispatchers.IO) {
            val pm = packageManager

            @Suppress("DEPRECATION")
            val installed = pm.getInstalledApplications(0)

            installed.mapNotNull { info: ApplicationInfo ->
                val launchIntent = pm.getLaunchIntentForPackage(info.packageName)

                if (launchIntent == null || info.packageName == packageName) {
                    null
                } else {
                    AppInfo(
                        label = pm.getApplicationLabel(info).toString(),
                        packageName = info.packageName
                    )
                }
            }.sortedBy { it.label.lowercase() }
        }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NetSwitchScreen(
    initialBlocked: Set<String>,
    onBlockedAppsChanged: (Set<String>) -> Unit,
    loadApps: suspend () -> List<AppInfo>
) {
    var apps by remember { mutableStateOf<List<AppInfo>>(emptyList()) }
    var blocked by remember { mutableStateOf(initialBlocked.toSet()) }
    var search by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        apps = loadApps()
        loading = false
    }

    val visibleApps = remember(apps, search) {
        apps.filter {
            it.label.contains(search, ignoreCase = true) ||
                it.packageName.contains(search, ignoreCase = true)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("NetSwitch", fontWeight = FontWeight.Bold)
                        Text(
                            "Per-app internet firewall",
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                },
                navigationIcon = {
                    Icon(
                        Icons.Default.Shield,
                        contentDescription = null,
                        modifier = Modifier.padding(start = 16.dp)
                    )
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp, bottom = 14.dp),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                )
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text(
                        "Your internet stays ON",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Only apps marked BLOCK are sent into NetSwitch and have their traffic discarded.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        AssistChip(
                            onClick = {},
                            label = { Text("Wi-Fi + Mobile data") },
                            leadingIcon = {
                                Icon(Icons.Default.Shield, null)
                            }
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "${blocked.size} blocked",
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                }
            }

            OutlinedTextField(
                value = search,
                onValueChange = { search = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Search installed apps") },
                leadingIcon = {
                    Icon(Icons.Default.Search, contentDescription = null)
                },
                singleLine = true
            )

            Spacer(Modifier.height(12.dp))

            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    "YOUR APPS",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    "Switch ON = allow",
                    style = MaterialTheme.typography.labelSmall
                )
            }

            Spacer(Modifier.height(6.dp))

            when {
                loading -> {
                    Box(
                        Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator()
                    }
                }

                visibleApps.isEmpty() -> {
                    Box(
                        Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("No matching apps found")
                    }
                }

                else -> {
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(bottom = 20.dp)
                    ) {
                        items(
                            visibleApps,
                            key = { it.packageName }
                        ) { app ->
                            val isAllowed = app.packageName !in blocked

                            ListItem(
                                headlineContent = {
                                    Text(
                                        app.label,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                },
                                supportingContent = {
                                    Text(
                                        if (isAllowed) {
                                            "Internet allowed"
                                        } else {
                                            "Internet blocked"
                                        }
                                    )
                                },
                                trailingContent = {
                                    Switch(
                                        checked = isAllowed,
                                        onCheckedChange = { allow ->
                                            val next =
                                                if (allow) {
                                                    blocked - app.packageName
                                                } else {
                                                    blocked + app.packageName
                                                }

                                            blocked = next
                                            onBlockedAppsChanged(next)
                                        }
                                    )
                                }
                            )
                            HorizontalDivider()
                        }
                    }
                }
            }

            Text(
                "Tip: Switch OFF an app to block it. Android may ask you to approve the local VPN.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(vertical = 8.dp)
            )
        }
    }
}
