package com.example.netswitch

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import java.io.FileInputStream
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Local blackhole VPN:
 * - only packages explicitly added with addAllowedApplication() enter this VPN;
 * - those packages' IPv4/IPv6 packets are drained and discarded;
 * - no packets are forwarded to a remote server.
 */
class FirewallVpnService : VpnService() {
    companion object {
        const val ACTION_UPDATE = "com.example.netswitch.UPDATE"
        const val EXTRA_BLOCKED_PACKAGES = "blocked_packages"
        private const val CHANNEL_ID = "netswitch_firewall"
        private const val NOTIFICATION_ID = 1001
    }

    private var tun: ParcelFileDescriptor? = null
    private var readerThread: Thread? = null
    private val running = AtomicBoolean(false)

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification("Preparing firewall…"))

        if (intent?.action == ACTION_UPDATE) {
            val packages = intent.getStringArrayListExtra(EXTRA_BLOCKED_PACKAGES).orEmpty().toSet()
            updateFirewall(packages)
        }
        return START_NOT_STICKY
    }

    private fun updateFirewall(blockedPackages: Set<String>) {
        stopTunnel()

        if (blockedPackages.isEmpty()) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return
        }

        try {
            val builder = Builder()
                .setSession("NetSwitch")
                .setMtu(1500)
                .addAddress("10.111.0.1", 32)
                .addAddress("fd11:1111:1111::1", 128)
                .addRoute("0.0.0.0", 0)
                .addRoute("::", 0)
                // A reserved, non-routable resolver address. DNS requests from
                // blocked apps enter the tunnel and are discarded as well.
                .addDnsServer("198.18.0.1")

            blockedPackages.forEach { packageName ->
                builder.addAllowedApplication(packageName)
            }

            tun = builder.establish()
            if (tun == null) {
                updateNotification("Could not establish local VPN")
                stopSelf()
                return
            }

            running.set(true)
            readerThread = Thread({
                val buffer = ByteArray(32767)
                try {
                    FileInputStream(tun!!.fileDescriptor).use { input ->
                        while (running.get()) {
                            val count = input.read(buffer)
                            if (count < 0) break
                            // Deliberately discard every packet: this is the firewall.
                        }
                    }
                } catch (_: Exception) {
                    // Expected when the VPN is closed or revoked.
                }
            }, "NetSwitch-PacketDropper").also {
                it.isDaemon = true
                it.start()
            }

            updateNotification("${blockedPackages.size} app(s) blocked")
        } catch (e: Exception) {
            updateNotification("Firewall error: ${e.message ?: "unknown error"}")
            stopTunnel()
            stopSelf()
        }
    }

    private fun stopTunnel() {
        running.set(false)
        try { tun?.close() } catch (_: Exception) {}
        tun = null
        readerThread = null
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "NetSwitch firewall", NotificationManager.IMPORTANCE_LOW
            ).apply { description = "Shows when NetSwitch is blocking selected apps" }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(message: String): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle("NetSwitch is active")
            .setContentText(message)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()

    private fun updateNotification(message: String) {
        getSystemService(NotificationManager::class.java)
            .notify(NOTIFICATION_ID, buildNotification(message))
    }

    override fun onRevoke() {
        stopTunnel()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
        super.onRevoke()
    }

    override fun onDestroy() {
        stopTunnel()
        super.onDestroy()
    }
}
