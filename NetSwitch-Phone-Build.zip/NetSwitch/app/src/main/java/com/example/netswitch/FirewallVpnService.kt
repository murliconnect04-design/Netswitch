
package com.example.netswitch

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import java.io.FileInputStream
import java.util.concurrent.atomic.AtomicBoolean

class FirewallVpnService : VpnService() {

    companion object {
        const val ACTION_UPDATE = "com.example.netswitch.UPDATE"
        const val EXTRA_BLOCKED_PACKAGES = "blocked_packages"

        private const val CHANNEL_ID = "netswitch_firewall"
        private const val NOTIFICATION_ID = 1001
    }

    private var tun: ParcelFileDescriptor? = null
    private var readerThread: Thread? = null
    private val running = AtomicBoolean(false)

    override fun onStartCommand(
        intent: Intent?,
        flags: Int,
        startId: Int
    ): Int {

        createNotificationChannel()

        startForeground(
            NOTIFICATION_ID,
            buildNotification("Starting firewall...")
        )

        val blockedPackages = if (intent?.action == ACTION_UPDATE) {
            intent.getStringArrayListExtra(
                EXTRA_BLOCKED_PACKAGES
            )?.toSet() ?: emptySet()
        } else {
            loadSavedBlockedApps()
        }

        updateFirewall(blockedPackages)

        return START_STICKY
    }

    private fun loadSavedBlockedApps(): Set<String> {
        return getSharedPreferences(
            MainActivity.PREFS_NAME,
            MODE_PRIVATE
        ).getStringSet(
            MainActivity.KEY_BLOCKED_APPS,
            emptySet()
        )?.toSet() ?: emptySet()
    }

    private fun updateFirewall(blockedPackages: Set<String>) {
        stopTunnel()

        if (blockedPackages.isEmpty()) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return
        }

        try {
            val builder = Builder()
                .setSession("NetSwitch")
                .setMtu(1500)
                .addAddress("10.111.0.1", 32)
                .addAddress("fd11:1111:1111::1", 128)
                .addRoute("0.0.0.0", 0)
                .addRoute("::", 0)
                .addDnsServer("198.18.0.1")

            blockedPackages.forEach { packageName ->
                builder.addAllowedApplication(packageName)
            }

            tun = builder.establish()

            if (tun == null) {
                updateNotification("Could not establish local VPN")
                stopSelf()
                return
            }

            running.set(true)

            val descriptor = tun!!

            readerThread = Thread({
                val buffer = ByteArray(32767)

                try {
                    FileInputStream(
                        descriptor.fileDescriptor
                    ).use { input ->
                        while (running.get()) {
                            val count = input.read(buffer)
                            if (count < 0) break
                        }
                    }
                } catch (_: Exception) {
                    // Tunnel closed or VPN revoked.
                }
            }, "NetSwitch-PacketDropper").also {
                it.isDaemon = true
                it.start()
            }

            updateNotification(
                "${blockedPackages.size} app(s) blocked"
            )

        } catch (e: Exception) {
            updateNotification(
                "Firewall error: ${e.message ?: "unknown error"}"
            )
            stopTunnel()
            stopSelf()
        }
    }

    private fun stopTunnel() {
        running.set(false)

        try {
            tun?.close()
        } catch (_: Exception) {
        }

        tun = null
        readerThread = null
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "NetSwitch firewall",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description =
                    "Shows when NetSwitch is blocking selected apps"
            }

            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(channel)
        }
    }

    private fun buildNotification(message: String): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle("NetSwitch")
            .setContentText(message)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    private fun updateNotification(message: String) {
        getSystemService(NotificationManager::class.java)
            .notify(
                NOTIFICATION_ID,
                buildNotification(message)
            )
    }

    override fun onRevoke() {
        stopTunnel()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
        super.onRevoke()
    }

    override fun onDestroy() {
        stopTunnel()
        super.onDestroy()
    }
}
