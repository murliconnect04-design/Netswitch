package com.example.netswitch

data class AppInfo(
    val label: String,
    val packageName: String
)
