# NetSwitch

NetSwitch is an Android per-app internet blocking MVP.

## What it does
- Lists launchable installed apps.
- Lets you mark apps as BLOCK or ALLOW.
- Uses Android `VpnService` with an allow-list containing only blocked apps.
- Routes those selected apps into a local VPN interface and discards their packets.
- Other apps bypass this VPN and continue using Wi-Fi/mobile data normally.
- The local VPN does not forward traffic to a remote server.

## Important limitations
- Android permits only one active VPN at a time. NetSwitch can conflict with another VPN, ad blocker, or firewall.
- Apps that require internet may not start or function while blocked.
- Some apps may use companion processes or services; test each app.
- Android system services and certain device traffic are outside the scope of this MVP.
- The VPN notification must remain visible while filtering is active.
- This MVP blocks traffic for selected apps on both Wi-Fi and cellular networks. It does not selectively block only background traffic.
- The app list currently includes launchable installed apps. Work-profile/private-space apps may not appear.
- `QUERY_ALL_PACKAGES` is used for a personal/sideloaded build. Google Play restricts broad app visibility; a Play Store release needs a policy-compliant app discovery design and approval.

## Build
1. Install Android Studio (Ladybug or newer) and Android SDK 35.
2. Open this folder in Android Studio.
3. Let Gradle sync.
4. Connect an Android phone with USB debugging enabled, or use an emulator.
5. Run the `app` configuration.
6. Approve Android's VPN connection prompt.
7. Select an app and switch it to BLOCK.

## Generate an APK
Android Studio: Build > Build Bundle(s) / APK(s) > Build APK(s).

Debug APK output:
`app/build/outputs/apk/debug/app-debug.apk`

## Implementation notes
The service uses `VpnService.Builder.addAllowedApplication()` for each blocked package.
When an allow-list is configured, only those selected apps enter the VPN. A reader thread drains and
discards packets from the TUN interface. No packet forwarding, DNS proxying, packet inspection, or
remote VPN server is implemented.

For safety, the VPN is stopped if the selected block list is empty.
